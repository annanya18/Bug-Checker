import { useState } from 'react';
import { AlertTriangle, AlertOctagon, Info, ArrowRight, Copy, Check, Code, Cpu, Layout, Shield } from 'lucide-react';

interface IssueCardProps {
  issue: {
    id: number;
    type: string;
    severity: string;
    title: string;
    description: string;
    location: string;
    suggestedFix: string;
    ai: string;
  };
}

const IssueCard = ({ issue }: IssueCardProps) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [isApplied, setIsApplied] = useState(false);

  const getSeverityIcon = () => {
    switch (issue.severity) {
      case 'critical':
        return <AlertOctagon className="h-5 w-5 text-red-500 dark:text-red-400" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-amber-500 dark:text-amber-400" />;
      default:
        return <Info className="h-5 w-5 text-blue-500 dark:text-blue-400" />;
    }
  };

  const getTypeIcon = () => {
    switch (issue.type) {
      case 'frontend':
        return <Layout className="h-4 w-4" />;
      case 'backend':
        return <Cpu className="h-4 w-4" />;
      case 'security':
        return <Shield className="h-4 w-4" />;
      default:
        return <Code className="h-4 w-4" />;
    }
  };

  const getTypeColor = () => {
    switch (issue.type) {
      case 'frontend':
        return 'bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-300';
      case 'backend':
        return 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300';
      case 'accessibility':
        return 'bg-teal-100 dark:bg-teal-900/30 text-teal-800 dark:text-teal-300';
      case 'performance':
        return 'bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-300';
      default:
        return 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-300';
    }
  };

  const handleCopyFix = () => {
    navigator.clipboard.writeText(issue.suggestedFix);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const handleApplyFix = () => {
    // This would typically interact with your codebase to apply the fix
    setIsApplied(true);
    setTimeout(() => setIsApplied(false), 2000);
  };

  return (
    <div className={`border rounded-lg overflow-hidden transition-all duration-300 ${
      isExpanded ? 'shadow-md' : 'shadow-sm'
    } ${
      issue.severity === 'critical'
        ? 'border-red-200 dark:border-red-800/30'
        : issue.severity === 'warning'
          ? 'border-amber-200 dark:border-amber-800/30'
          : 'border-blue-200 dark:border-blue-800/30'
    }`}>
      <div 
        className="flex items-center p-4 cursor-pointer bg-white dark:bg-gray-800 hover:bg-gray-50 dark:hover:bg-gray-750 transition-colors"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="mr-3">
          {getSeverityIcon()}
        </div>
        <div className="flex-grow">
          <h3 className="font-medium text-gray-900 dark:text-gray-100">{issue.title}</h3>
          <div className="flex items-center mt-1">
            <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${getTypeColor()}`}>
              {getTypeIcon()}
              <span className="ml-1 capitalize">{issue.type}</span>
            </span>
            <span className="mx-2 text-gray-400 dark:text-gray-500">•</span>
            <span className="text-sm text-gray-500 dark:text-gray-400 truncate">
              {issue.location}
            </span>
            <span className="mx-2 text-gray-400 dark:text-gray-500">•</span>
            <span className="text-xs px-1.5 py-0.5 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded uppercase">
              {issue.ai}
            </span>
          </div>
        </div>
        <div className="ml-4">
          <ArrowRight className={`h-5 w-5 text-gray-400 transform transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
        </div>
      </div>
      
      {isExpanded && (
        <div className="px-4 py-3 bg-gray-50 dark:bg-gray-700/30 border-t border-gray-100 dark:border-gray-700">
          <p className="text-gray-700 dark:text-gray-300 mb-4">
            {issue.description}
          </p>
          
          <div className="mb-4">
            <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Suggested Fix:</h4>
            <pre className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-md p-3 text-sm overflow-x-auto">
              <code className="text-gray-800 dark:text-gray-200 font-mono whitespace-pre">
                {issue.suggestedFix}
              </code>
            </pre>
          </div>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={handleCopyFix}
              className="flex items-center px-3 py-1 text-sm font-medium text-gray-700 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded hover:bg-gray-50 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
            >
              {isCopied ? <Check className="h-4 w-4 mr-1 text-green-500" /> : <Copy className="h-4 w-4 mr-1" />}
              {isCopied ? 'Copied!' : 'Copy Fix'}
            </button>
            
            <button
              onClick={handleApplyFix}
              className="flex items-center px-3 py-1 text-sm font-medium text-white bg-blue-600 dark:bg-blue-500 border border-blue-600 dark:border-blue-500 rounded hover:bg-blue-700 dark:hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors"
            >
              {isApplied ? <Check className="h-4 w-4 mr-1" /> : <Code className="h-4 w-4 mr-1" />}
              {isApplied ? 'Applied!' : 'Apply Fix'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default IssueCard;