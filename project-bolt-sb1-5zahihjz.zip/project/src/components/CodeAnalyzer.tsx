import { useState } from 'react';
import { Code, FileCode } from 'lucide-react';

interface CodeAnalyzerProps {
  onAnalyze: (code: string, language: string) => void;
  isAnalyzing: boolean;
}

const CodeAnalyzer = ({ onAnalyze, isAnalyzing }: CodeAnalyzerProps) => {
  const [code, setCode] = useState('');
  const [language, setLanguage] = useState('javascript');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!code.trim()) {
      setError('Please enter some code to analyze');
      return;
    }
    
    setError('');
    onAnalyze(code, language);
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 mb-8 transition-all duration-300 transform hover:shadow-md">
      <h2 className="text-2xl font-bold mb-6 text-gray-800 dark:text-gray-100">Analyze Code for Bugs</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
          <div className="md:col-span-1">
            <label htmlFor="language" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
              Language
            </label>
            <select
              id="language"
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="w-full px-3 py-2 rounded-md border border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            >
              <option value="javascript">JavaScript</option>
              <option value="typescript">TypeScript</option>
              <option value="html">HTML</option>
              <option value="css">CSS</option>
              <option value="python">Python</option>
              <option value="java">Java</option>
              <option value="csharp">C#</option>
              <option value="php">PHP</option>
            </select>
          </div>
          
          <div className="md:col-span-3">
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="code" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                Code to Analyze
              </label>
              <div className="flex items-center">
                <FileCode className="h-4 w-4 text-gray-500 dark:text-gray-400 mr-1" />
                <span className="text-xs text-gray-500 dark:text-gray-400">
                  Paste code or upload file
                </span>
              </div>
            </div>
            <div className="relative">
              <textarea
                id="code"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="// Paste your code here for analysis"
                rows={10}
                className={`w-full px-4 py-3 rounded-lg border ${
                  error ? 'border-red-500 dark:border-red-600' : 'border-gray-300 dark:border-gray-600'
                } focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 font-mono text-sm transition-all duration-200`}
              ></textarea>
              
              <div className="absolute bottom-2 right-2">
                <button
                  type="button"
                  className="p-1 rounded bg-gray-200 dark:bg-gray-600 text-gray-600 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-500 transition-colors"
                  onClick={() => setCode('')}
                  aria-label="Clear code"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {error && (
          <p className="text-red-500 dark:text-red-400 text-sm mt-1">{error}</p>
        )}
        
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isAnalyzing}
            className={`px-6 py-3 rounded-lg bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-blue-400 flex items-center space-x-2 ${
              isAnalyzing ? 'opacity-70 cursor-not-allowed' : ''
            }`}
          >
            {isAnalyzing ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>Analyzing...</span>
              </>
            ) : (
              <>
                <Code className="h-5 w-5 mr-1" />
                <span>Analyze Code</span>
              </>
            )}
          </button>
        </div>
      </form>

      <div className="mt-8 text-gray-600 dark:text-gray-400">
        <h3 className="text-lg font-medium mb-2">What we check for:</h3>
        <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 pl-5 list-disc">
          <li>Syntax errors and best practices</li>
          <li>Potential runtime errors</li>
          <li>Security vulnerabilities</li>
          <li>Performance bottlenecks</li>
          <li>Accessibility issues</li>
          <li>Compatibility problems</li>
        </ul>
      </div>
    </div>
  );
};

export default CodeAnalyzer;