import { useState } from 'react';
import IssueCard from './IssueCard';
import PerformanceChart from './PerformanceChart';
import { AlertTriangle, CheckCircle, Info, AlertOctagon } from 'lucide-react';

interface ResultsPanelProps {
  results: any;
}

const ResultsPanel = ({ results }: ResultsPanelProps) => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSeverity, setSelectedSeverity] = useState<string | null>(null);

  // Filter issues based on selected filters
  const filteredIssues = results.issues.filter((issue: any) => {
    let categoryMatch = true;
    let severityMatch = true;
    
    if (selectedCategory) {
      categoryMatch = issue.type === selectedCategory;
    }
    
    if (selectedSeverity) {
      severityMatch = issue.severity === selectedSeverity;
    }
    
    return categoryMatch && severityMatch;
  });

  return (
    <div className="mt-8 space-y-8 animate-fadeIn">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 transition-all duration-300 transform hover:shadow-md">
        <h2 className="text-2xl font-bold mb-6 text-gray-800 dark:text-gray-100">Analysis Results</h2>
        
        {/* Summary Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800/30 rounded-lg p-4 flex items-center">
            <div className="p-2 bg-red-500/10 dark:bg-red-500/20 rounded-full mr-4">
              <AlertOctagon className="h-6 w-6 text-red-500 dark:text-red-400" />
            </div>
            <div>
              <p className="text-sm text-red-800 dark:text-red-300">Critical Issues</p>
              <p className="text-2xl font-bold text-red-600 dark:text-red-400">{results.summary.criticalIssues}</p>
            </div>
          </div>
          
          <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800/30 rounded-lg p-4 flex items-center">
            <div className="p-2 bg-amber-500/10 dark:bg-amber-500/20 rounded-full mr-4">
              <AlertTriangle className="h-6 w-6 text-amber-500 dark:text-amber-400" />
            </div>
            <div>
              <p className="text-sm text-amber-800 dark:text-amber-300">Warnings</p>
              <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">{results.summary.warningIssues}</p>
            </div>
          </div>
          
          <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800/30 rounded-lg p-4 flex items-center">
            <div className="p-2 bg-blue-500/10 dark:bg-blue-500/20 rounded-full mr-4">
              <Info className="h-6 w-6 text-blue-500 dark:text-blue-400" />
            </div>
            <div>
              <p className="text-sm text-blue-800 dark:text-blue-300">Info</p>
              <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">{results.summary.infoIssues}</p>
            </div>
          </div>
          
          <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800/30 rounded-lg p-4 flex items-center">
            <div className="p-2 bg-green-500/10 dark:bg-green-500/20 rounded-full mr-4">
              <CheckCircle className="h-6 w-6 text-green-500 dark:text-green-400" />
            </div>
            <div>
              <p className="text-sm text-green-800 dark:text-green-300">Total Fixed</p>
              <p className="text-2xl font-bold text-green-600 dark:text-green-400">0</p>
            </div>
          </div>
        </div>
        
        {/* Category Breakdown */}
        <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4 mb-8">
          <h3 className="font-medium text-gray-700 dark:text-gray-300 mb-3">Issues by Category</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <button
              onClick={() => setSelectedCategory(selectedCategory === 'frontend' ? null : 'frontend')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                selectedCategory === 'frontend'
                  ? 'bg-purple-100 dark:bg-purple-900/30 text-purple-700 dark:text-purple-300 border border-purple-200 dark:border-purple-800/30'
                  : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600 hover:bg-purple-50 dark:hover:bg-purple-900/10'
              }`}
            >
              Frontend ({results.summary.categories.frontend})
            </button>
            <button
              onClick={() => setSelectedCategory(selectedCategory === 'backend' ? null : 'backend')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                selectedCategory === 'backend'
                  ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/30'
                  : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600 hover:bg-blue-50 dark:hover:bg-blue-900/10'
              }`}
            >
              Backend ({results.summary.categories.backend})
            </button>
            <button
              onClick={() => setSelectedCategory(selectedCategory === 'accessibility' ? null : 'accessibility')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                selectedCategory === 'accessibility'
                  ? 'bg-teal-100 dark:bg-teal-900/30 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800/30'
                  : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600 hover:bg-teal-50 dark:hover:bg-teal-900/10'
              }`}
            >
              Accessibility ({results.summary.categories.accessibility})
            </button>
            <button
              onClick={() => setSelectedCategory(selectedCategory === 'performance' ? null : 'performance')}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                selectedCategory === 'performance'
                  ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800/30'
                  : 'bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-600 hover:bg-amber-50 dark:hover:bg-amber-900/10'
              }`}
            >
              Performance ({results.summary.categories.performance})
            </button>
          </div>
        </div>
        
        {/* Severity Filter */}
        <div className="mb-6">
          <h3 className="font-medium text-gray-700 dark:text-gray-300 mb-3">Filter by Severity</h3>
          <div className="flex space-x-2">
            <button
              onClick={() => setSelectedSeverity(selectedSeverity === 'critical' ? null : 'critical')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                selectedSeverity === 'critical'
                  ? 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-red-50 dark:hover:bg-red-900/10'
              }`}
            >
              Critical
            </button>
            <button
              onClick={() => setSelectedSeverity(selectedSeverity === 'warning' ? null : 'warning')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                selectedSeverity === 'warning'
                  ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-amber-50 dark:hover:bg-amber-900/10'
              }`}
            >
              Warning
            </button>
            <button
              onClick={() => setSelectedSeverity(selectedSeverity === 'info' ? null : 'info')}
              className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                selectedSeverity === 'info'
                  ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-blue-50 dark:hover:bg-blue-900/10'
              }`}
            >
              Info
            </button>
          </div>
        </div>
        
        {/* Issues List */}
        <div className="space-y-4">
          {filteredIssues.length > 0 ? (
            filteredIssues.map((issue: any) => (
              <IssueCard key={issue.id} issue={issue} />
            ))
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500 dark:text-gray-400">No issues found with the selected filters.</p>
              <button
                onClick={() => {
                  setSelectedCategory(null);
                  setSelectedSeverity(null);
                }}
                className="mt-2 text-blue-600 dark:text-blue-400 text-sm hover:underline"
              >
                Clear filters
              </button>
            </div>
          )}
        </div>
      </div>
      
      {/* Performance Section */}
      {results.performanceMetrics && (
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 transition-all duration-300 transform hover:shadow-md">
          <h2 className="text-2xl font-bold mb-6 text-gray-800 dark:text-gray-100">Performance Metrics</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div>
              <PerformanceChart metrics={results.performanceMetrics} />
            </div>
            <div className="space-y-4">
              <div className="border-l-4 border-blue-500 dark:border-blue-400 pl-4">
                <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200">Core Web Vitals</h3>
                <p className="text-gray-600 dark:text-gray-400 text-sm mt-1">
                  Key metrics that Google uses to measure user experience.
                </p>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Largest Contentful Paint</span>
                    <span className={`text-sm font-medium px-2 py-1 rounded-full ${
                      parseFloat(results.performanceMetrics.largestContentfulPaint) < 2.5
                        ? 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300'
                        : parseFloat(results.performanceMetrics.largestContentfulPaint) < 4
                          ? 'bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300'
                          : 'bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300'
                    }`}>
                      {results.performanceMetrics.largestContentfulPaint}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-600 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        parseFloat(results.performanceMetrics.largestContentfulPaint) < 2.5
                          ? 'bg-green-500'
                          : parseFloat(results.performanceMetrics.largestContentfulPaint) < 4
                            ? 'bg-amber-500'
                            : 'bg-red-500'
                      }`}
                      style={{ width: `${Math.min(100, (parseFloat(results.performanceMetrics.largestContentfulPaint) / 5) * 100)}%` }}
                    ></div>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                    Good: &lt; 2.5s | Needs Improvement: 2.5s - 4s | Poor: &gt; 4s
                  </p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Total Blocking Time</span>
                    <span className={`text-sm font-medium px-2 py-1 rounded-full ${
                      parseInt(results.performanceMetrics.totalBlockingTime) < 200
                        ? 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300'
                        : parseInt(results.performanceMetrics.totalBlockingTime) < 600
                          ? 'bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300'
                          : 'bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300'
                    }`}>
                      {results.performanceMetrics.totalBlockingTime}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-600 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        parseInt(results.performanceMetrics.totalBlockingTime) < 200
                          ? 'bg-green-500'
                          : parseInt(results.performanceMetrics.totalBlockingTime) < 600
                            ? 'bg-amber-500'
                            : 'bg-red-500'
                      }`}
                      style={{ width: `${Math.min(100, (parseInt(results.performanceMetrics.totalBlockingTime) / 1000) * 100)}%` }}
                    ></div>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                    Good: &lt; 200ms | Needs Improvement: 200ms - 600ms | Poor: &gt; 600ms
                  </p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-600 dark:text-gray-400">Cumulative Layout Shift</span>
                    <span className={`text-sm font-medium px-2 py-1 rounded-full ${
                      parseFloat(results.performanceMetrics.cumulativeLayoutShift) < 0.1
                        ? 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300'
                        : parseFloat(results.performanceMetrics.cumulativeLayoutShift) < 0.25
                          ? 'bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300'
                          : 'bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300'
                    }`}>
                      {results.performanceMetrics.cumulativeLayoutShift}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-600 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        parseFloat(results.performanceMetrics.cumulativeLayoutShift) < 0.1
                          ? 'bg-green-500'
                          : parseFloat(results.performanceMetrics.cumulativeLayoutShift) < 0.25
                            ? 'bg-amber-500'
                            : 'bg-red-500'
                      }`}
                      style={{ width: `${Math.min(100, (parseFloat(results.performanceMetrics.cumulativeLayoutShift) / 0.5) * 100)}%` }}
                    ></div>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                    Good: &lt; 0.1 | Needs Improvement: 0.1 - 0.25 | Poor: &gt; 0.25
                  </p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-gray-600 dark:text-gray-400">First Contentful Paint</span>
                    <span className={`text-sm font-medium px-2 py-1 rounded-full ${
                      parseFloat(results.performanceMetrics.firstContentfulPaint) < 1.8
                        ? 'bg-green-100 dark:bg-green-900/20 text-green-800 dark:text-green-300'
                        : parseFloat(results.performanceMetrics.firstContentfulPaint) < 3
                          ? 'bg-amber-100 dark:bg-amber-900/20 text-amber-800 dark:text-amber-300'
                          : 'bg-red-100 dark:bg-red-900/20 text-red-800 dark:text-red-300'
                    }`}>
                      {results.performanceMetrics.firstContentfulPaint}
                    </span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-600 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        parseFloat(results.performanceMetrics.firstContentfulPaint) < 1.8
                          ? 'bg-green-500'
                          : parseFloat(results.performanceMetrics.firstContentfulPaint) < 3
                            ? 'bg-amber-500'
                            : 'bg-red-500'
                      }`}
                      style={{ width: `${Math.min(100, (parseFloat(results.performanceMetrics.firstContentfulPaint) / 4) * 100)}%` }}
                    ></div>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                    Good: &lt; 1.8s | Needs Improvement: 1.8s - 3s | Poor: &gt; 3s
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ResultsPanel;