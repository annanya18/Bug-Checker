import { useState } from 'react';

interface PerformanceChartProps {
  metrics: {
    firstContentfulPaint: string;
    largestContentfulPaint: string;
    totalBlockingTime: string;
    cumulativeLayoutShift: string;
    speedIndex: string;
  };
}

// Helper function to determine the color based on the metric value
const getMetricColor = (metric: string, value: string): string => {
  const numValue = parseFloat(value.replace('s', '').replace('ms', ''));
  
  switch (metric) {
    case 'First Contentful Paint':
      return numValue < 1.8 ? '#10B981' : numValue < 3 ? '#F59E0B' : '#EF4444';
    case 'Largest Contentful Paint':
      return numValue < 2.5 ? '#10B981' : numValue < 4 ? '#F59E0B' : '#EF4444';
    case 'Total Blocking Time':
      // Assuming TBT is in ms
      return numValue < 200 ? '#10B981' : numValue < 600 ? '#F59E0B' : '#EF4444';
    case 'Cumulative Layout Shift':
      return numValue < 0.1 ? '#10B981' : numValue < 0.25 ? '#F59E0B' : '#EF4444';
    case 'Speed Index':
      return numValue < 3.4 ? '#10B981' : numValue < 5.8 ? '#F59E0B' : '#EF4444';
    default:
      return '#3B82F6';
  }
};

const PerformanceChart = ({ metrics }: PerformanceChartProps) => {
  const [hoveredMetric, setHoveredMetric] = useState<string | null>(null);
  
  // Prepare the data for visualization
  const metricData = [
    { name: 'First Contentful Paint', value: metrics.firstContentfulPaint, max: 5 },
    { name: 'Largest Contentful Paint', value: metrics.largestContentfulPaint, max: 6 },
    { name: 'Total Blocking Time', value: metrics.totalBlockingTime.replace('ms', ''), max: 1000 },
    { name: 'Cumulative Layout Shift', value: metrics.cumulativeLayoutShift, max: 0.5 },
    { name: 'Speed Index', value: metrics.speedIndex, max: 8 }
  ];

  return (
    <div className="performance-chart">
      <h3 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-4">Performance Visualization</h3>
      
      <div className="space-y-4">
        {metricData.map((metric) => {
          const percentValue = parseFloat(metric.value.replace('s', '')) / metric.max * 100;
          const safePercent = Math.min(Math.max(percentValue, 0), 100);
          const color = getMetricColor(metric.name, metric.value);
          
          // Calculate label positioning
          const labelPosition = `${Math.min(safePercent, 95)}%`;
          
          const isHovered = hoveredMetric === metric.name;
          
          return (
            <div 
              key={metric.name} 
              className="relative"
              onMouseEnter={() => setHoveredMetric(metric.name)}
              onMouseLeave={() => setHoveredMetric(null)}
            >
              <div className="flex justify-between mb-1">
                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                  {metric.name}
                </span>
                <span 
                  className={`text-sm font-semibold transition-colors ${
                    color === '#10B981' 
                      ? 'text-green-600 dark:text-green-400' 
                      : color === '#F59E0B' 
                        ? 'text-amber-600 dark:text-amber-400'
                        : 'text-red-600 dark:text-red-400'
                  }`}
                >
                  {metric.value}
                </span>
              </div>
              <div className="relative w-full h-3 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden transition-all">
                <div 
                  className="h-full rounded-full transition-all duration-500 ease-out"
                  style={{ 
                    width: `${safePercent}%`, 
                    backgroundColor: color,
                    boxShadow: isHovered ? `0 0 8px ${color}` : 'none',
                  }}
                ></div>
                
                {/* Thresholds */}
                {metric.name === 'First Contentful Paint' && (
                  <>
                    <div className="absolute top-0 bottom-0 border-l border-dashed border-green-500 dark:border-green-400 opacity-50" style={{ left: `${1.8/metric.max*100}%` }}></div>
                    <div className="absolute top-0 bottom-0 border-l border-dashed border-amber-500 dark:border-amber-400 opacity-50" style={{ left: `${3/metric.max*100}%` }}></div>
                  </>
                )}
                
                {metric.name === 'Largest Contentful Paint' && (
                  <>
                    <div className="absolute top-0 bottom-0 border-l border-dashed border-green-500 dark:border-green-400 opacity-50" style={{ left: `${2.5/metric.max*100}%` }}></div>
                    <div className="absolute top-0 bottom-0 border-l border-dashed border-amber-500 dark:border-amber-400 opacity-50" style={{ left: `${4/metric.max*100}%` }}></div>
                  </>
                )}
                
                {metric.name === 'Total Blocking Time' && (
                  <>
                    <div className="absolute top-0 bottom-0 border-l border-dashed border-green-500 dark:border-green-400 opacity-50" style={{ left: `${200/metric.max*100}%` }}></div>
                    <div className="absolute top-0 bottom-0 border-l border-dashed border-amber-500 dark:border-amber-400 opacity-50" style={{ left: `${600/metric.max*100}%` }}></div>
                  </>
                )}
                
                {metric.name === 'Cumulative Layout Shift' && (
                  <>
                    <div className="absolute top-0 bottom-0 border-l border-dashed border-green-500 dark:border-green-400 opacity-50" style={{ left: `${0.1/metric.max*100}%` }}></div>
                    <div className="absolute top-0 bottom-0 border-l border-dashed border-amber-500 dark:border-amber-400 opacity-50" style={{ left: `${0.25/metric.max*100}%` }}></div>
                  </>
                )}
              </div>
              
              {isHovered && (
                <div className="absolute -bottom-10 left-0 right-0 text-xs text-center text-gray-500 dark:text-gray-400 pointer-events-none">
                  <div className="relative inline-block">
                    <div className="bg-white dark:bg-gray-800 shadow-sm px-2 py-1 rounded">
                      {metric.name === 'First Contentful Paint' && 'Good: < 1.8s, Needs Improvement: 1.8s-3s, Poor: > 3s'}
                      {metric.name === 'Largest Contentful Paint' && 'Good: < 2.5s, Needs Improvement: 2.5s-4s, Poor: > 4s'}
                      {metric.name === 'Total Blocking Time' && 'Good: < 200ms, Needs Improvement: 200ms-600ms, Poor: > 600ms'}
                      {metric.name === 'Cumulative Layout Shift' && 'Good: < 0.1, Needs Improvement: 0.1-0.25, Poor: > 0.25'}
                      {metric.name === 'Speed Index' && 'Good: < 3.4s, Needs Improvement: 3.4s-5.8s, Poor: > 5.8s'}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default PerformanceChart;