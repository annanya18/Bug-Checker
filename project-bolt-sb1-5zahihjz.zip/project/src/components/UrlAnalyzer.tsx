import { useState } from 'react';
import { Search } from 'lucide-react';

interface UrlAnalyzerProps {
  onAnalyze: (url: string) => void;
  isAnalyzing: boolean;
}

const UrlAnalyzer = ({ onAnalyze, isAnalyzing }: UrlAnalyzerProps) => {
  const [url, setUrl] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic URL validation
    if (!url) {
      setError('Please enter a URL');
      return;
    }
    
    try {
      // Check if it's a valid URL
      new URL(url);
      setError('');
      onAnalyze(url);
    } catch (err) {
      setError('Please enter a valid URL (e.g., https://example.com)');
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-6 mb-8 transition-all duration-300 transform hover:shadow-md">
      <h2 className="text-2xl font-bold mb-6 text-gray-800 dark:text-gray-100">Analyze Website for Bugs</h2>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="relative">
          <input
            type="text"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            placeholder="https://yourwebsite.com"
            className={`w-full px-4 py-3 rounded-lg border ${
              error ? 'border-red-500 dark:border-red-600' : 'border-gray-300 dark:border-gray-600'
            } focus:outline-none focus:ring-2 focus:ring-blue-500 dark:focus:ring-blue-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 pr-12 transition-all duration-200`}
          />
          <div className="absolute inset-y-0 right-0 flex items-center pr-3">
            <Search className="h-5 w-5 text-gray-400 dark:text-gray-500" />
          </div>
        </div>
        
        {error && (
          <p className="text-red-500 dark:text-red-400 text-sm mt-1">{error}</p>
        )}
        
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={isAnalyzing}
            className={`px-6 py-3 rounded-lg bg-blue-600 hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600 text-white font-medium transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 dark:focus:ring-blue-400 flex items-center space-x-2 ${
              isAnalyzing ? 'opacity-70 cursor-not-allowed' : ''
            }`}
          >
            {isAnalyzing ? (
              <>
                <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>Analyzing...</span>
              </>
            ) : (
              <span>Analyze Website</span>
            )}
          </button>
        </div>
      </form>
      
      <div className="mt-8 text-gray-600 dark:text-gray-400">
        <h3 className="text-lg font-medium mb-2">How it works:</h3>
        <ul className="list-disc pl-5 space-y-1">
          <li>Enter your website URL above</li>
          <li>Our AI will scan for frontend, backend, accessibility, and performance issues</li>
          <li>Review detailed diagnostics and suggested fixes</li>
          <li>Apply code solutions with one click</li>
        </ul>
      </div>
    </div>
  );
};

export default UrlAnalyzer;