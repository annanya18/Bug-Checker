import { useState } from 'react';
import { ThemeProvider } from './context/ThemeContext';
import Header from './components/Header';
import Footer from './components/Footer';
import UrlAnalyzer from './components/UrlAnalyzer';
import CodeAnalyzer from './components/CodeAnalyzer';
import ResultsPanel from './components/ResultsPanel';
import './App.css';

function App() {
  const [activeTab, setActiveTab] = useState<'url' | 'code'>('url');
  const [results, setResults] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleUrlAnalysis = (url: string) => {
    setIsAnalyzing(true);
    // Simulate API call
    setTimeout(() => {
      setResults(mockResults);
      setIsAnalyzing(false);
    }, 2000);
  };

  const handleCodeAnalysis = (code: string, language: string) => {
    setIsAnalyzing(true);
    // Simulate API call
    setTimeout(() => {
      setResults(mockResults);
      setIsAnalyzing(false);
    }, 2000);
  };

  return (
    <ThemeProvider>
      <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 transition-colors duration-200">
        <Header activeTab={activeTab} setActiveTab={setActiveTab} />
        <main className="flex-grow container mx-auto px-4 py-8 max-w-6xl">
          {activeTab === 'url' ? (
            <UrlAnalyzer onAnalyze={handleUrlAnalysis} isAnalyzing={isAnalyzing} />
          ) : (
            <CodeAnalyzer onAnalyze={handleCodeAnalysis} isAnalyzing={isAnalyzing} />
          )}
          
          {results && !isAnalyzing && (
            <ResultsPanel results={results} />
          )}
        </main>
        <Footer />
      </div>
    </ThemeProvider>
  );
}

// Mock data for demonstration
const mockResults = {
  summary: {
    totalIssues: 12,
    criticalIssues: 2,
    warningIssues: 5,
    infoIssues: 5,
    categories: {
      frontend: 4,
      backend: 2,
      accessibility: 3,
      performance: 3,
    },
  },
  issues: [
    {
      id: 1,
      type: 'frontend',
      severity: 'critical',
      title: 'Layout Overflow on Mobile Devices',
      description: 'Content extends beyond the viewport on mobile devices, causing horizontal scrolling.',
      location: 'main.css:245, HomePage.js:67',
      suggestedFix: `// Add this CSS to fix the overflow issue
.container {
  max-width: 100%;
  overflow-x: hidden;
}`,
      ai: 'cv',
    },
    {
      id: 2,
      type: 'backend',
      severity: 'critical',
      title: 'Unhandled Promise Rejection',
      description: 'API endpoint fails silently when the database connection is lost.',
      location: 'api/users.js:42',
      suggestedFix: `// Wrap the database call in a try/catch block
try {
  const users = await db.query('SELECT * FROM users');
  return res.json(users);
} catch (error) {
  console.error('Database error:', error);
  return res.status(500).json({ error: 'Database connection failed' });
}`,
      ai: 'nlp',
    },
    {
      id: 3,
      type: 'accessibility',
      severity: 'warning',
      title: 'Missing Alt Text on Images',
      description: '4 images are missing alt text, making them inaccessible to screen readers.',
      location: 'components/Gallery.js:12-28',
      suggestedFix: `// Add alt text to all images
<img src="product1.jpg" alt="Red sports shoes with white trim" />
<img src="product2.jpg" alt="Blue casual shoes with black laces" />
<img src="product3.jpg" alt="Black formal shoes with leather finish" />
<img src="product4.jpg" alt="Green hiking boots with reinforced toe" />`,
      ai: 'cv',
    },
    {
      id: 4,
      type: 'performance',
      severity: 'warning',
      title: 'Large Unoptimized Images',
      description: 'Several images exceed 1MB in size, slowing down page load time.',
      location: 'assets/hero.jpg, assets/background.jpg',
      suggestedFix: `// Optimize images and use next-gen formats
// Consider using WebP format and implementing responsive images:

<picture>
  <source srcset="hero.webp" type="image/webp">
  <source srcset="hero.jpg" type="image/jpeg">
  <img src="hero.jpg" alt="Hero image" loading="lazy">
</picture>`,
      ai: 'ml',
    },
  ],
  performanceMetrics: {
    firstContentfulPaint: '2.4s',
    largestContentfulPaint: '4.2s',
    totalBlockingTime: '420ms',
    cumulativeLayoutShift: '0.12',
    speedIndex: '3.8s',
  },
};

export default App;